## Change history

All changes to the guide can be found in the [Release Notes on Github](https://github.com/cogneon/lernos-zettelkasten/releases). The sources of all previous guide versions are also available there.
