# Learning path

## The learning objectives of the Zettelkasten pathway

![Zettelkasten-Learning objectives and kata overview](images/ZettelkastenLernziele_onepage.png)
<script src="https://giscus.app/client.js"
        data-repo="cogneon/lernos-zettelkasten"
        data-repo-id="R_kgDOI5YY1w"
        data-category="Announcements"
        data-category-id="DIC_kwDOI5YY184CUTx3"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="light"
        data-lang="en"
        crossorigin="anonymous"
        async>
</script>
