![The purpose of feedback](images/woche0.png)

## Kata 4 - Feedback

Used in [week 0](2-1-Woche-0.md)

### Theory
A very important function of the Circle is to get feedback on your goals, understanding and workflow, and to give feedback to others. To help you understand each other better, take a few moments to talk about your idea of constructive feedback.


### Reflection section
- How can we best give each other feedback to improve our goals and understanding?


### Learning Objective
- You gain clarity in the Circle about the procedure and the organization

<script src="https://giscus.app/client.js"
        data-repo="cogneon/lernos-zettelkasten"
        data-repo-id="R_kgDOI5YY1w"
        data-category="Announcements"
        data-category-id="DIC_kwDOI5YY184CUTx3"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="light"
        data-lang="de"
        crossorigin="anonymous"
        async>
</script>
