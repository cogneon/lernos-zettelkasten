![Danksagung](images/Danksagung.png)
# Acknowledgements

The guide was written by: [Andreas Trebing](https://www.linkedin.com/in/andreas-trebing-32872b143/), [Friederike Schoeller-Frey](https://www.linkedin.com/in/frey-32753b67/), [Maris Krobath](https://www.linkedin.com/in/martina-krobath/)


A big thank you for constructive feedback and corrections goes to:

- Moritz Meißner
- Stephan Diepolder
