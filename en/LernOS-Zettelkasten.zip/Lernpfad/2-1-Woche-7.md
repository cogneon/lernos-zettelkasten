![Stop](images/Boxenstopp.png)

## Woche 7 - Pit stop

Hey, congratulations! You've made it this far, that's already a reason to celebrate and pat each other on the back!

### As preparation

- [ ] [Kata 10](2-1-Kata-10.md): are you on Track?

- [ ] [Kata 11](2-1-Kata-11.md): Outlook

### In the Weekly

- [ ] Check in (2 minutes per member)

What has been on your mind this past week related to personal knowledge management?

#### Guiding questions

- Do you feel confident using your notebook?
- Do you feel comfortable with your goal and how far you have reached it?
- Do you have questions you would like to discuss among yourselves?

### Close

- [ ] Check Out (1 minute per member)

What are your plans for next week?


