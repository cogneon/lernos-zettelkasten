![Deepening the workflow](images/woche11.png)

## Week 10 - Deepening the workflow

This week is about reflecting on where you came from and what workflow you are implementing after the last few weeks.

### As preparation

- [ ] [Kata 17](2-1-Kata-17.md): Deepen the workflow

### In the Weekly

- [ ] Check in (2 minutes per member)

What has been on your mind this past week related to personal knowledge management?

#### Guiding questions

- Did you learn anything new while creating your workflow?

### Close

- [ ] Check Out (1 minute per member)

What are your plans for next week?


