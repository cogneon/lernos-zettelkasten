# Learning path

## The learning objectives of the Zettelkasten pathway

![Zettelkasten-Learning objectives and kata overview](images/ZettelkastenLernziele_onepage.png)

