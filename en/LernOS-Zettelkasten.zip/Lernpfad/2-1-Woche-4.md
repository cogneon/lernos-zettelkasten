![Workflow](images/woche11.png)

## Week 4 - Find your workflow


### As preparation

- [ ] [Kata 15](2-1-Kata-15.md): Find your workflow

### In the Weekly

- [ ] Check in (2 minutes per member)

What has been on your mind this past week related to personal knowledge management?

#### Guiding questions

- Did you learn anything new while creating your workflow?
- What are the key benefits of an established workflow in relation to the notebox method?
- What are the most important factors in keeping a workflow alive?
- How can you make sure your workflow is done by you on a regular basis?

### Close

- [ ] Check Out (1 minute per member)

What are your plans for next week?


