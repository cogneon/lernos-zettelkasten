## Änderungshistorie

Alle Änderungen des Leitfadens können in den [Release Notes auf Github](https://github.com/cogneon/lernos-zettelkasten/releases) nachgesehen werden. Dort stehen auch die Quellen aller früherer Leitfaden-Versionen zur Verfügung.
