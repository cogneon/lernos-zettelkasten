![Verlinkung von relevanten Informationen](images/woche6.png)

## Woche 6 - Verzetteln

du wirst dich mit dauerhaten Notizen beschäfigen, Notizen die du immer wieder verwdenden kannst.

### Als Vorbereitung

- [ ] [Kata 9](2-1-Kata-9.md): Verzetteln

### Im Weekly

- [ ] Check in (2 Minuten pro Member)

Was hat dich die letzte Woche im Zusammenhang mit persönlichem Wissensmanagement beschäftigt?

#### Leitfragen

- Würdest du beim nächsten Verzetteln anders vorgehen?
	- Was gefällt dir an deinem bisherigen Vorgehen?
	- Was würdest du beim nächsten Mal anders machen?
	- Was würde dir dabei helfen?
- Bist du mit dem Ergebnis zufrieden?

### Schluss

- [ ] Check-Out (1 Minute pro Member)

Was nimmst du dir für die nächste Woche vor?


