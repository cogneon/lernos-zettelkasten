# Lernpfad

## Die Lernziele des Zettelkasten-Pfades

![Zettelkasten-Lernziele und Kata überblicke](images/ZettelkastenLernziele_onepage.png)
