![Der Zweck von Feedback](images/woche0.png)

## Kata 4 - Feedback

Verwendet in [Woche 0](2-1-Woche-0.md)

### Theorie
Eine ganz wichtige Funktion des Circles ist es, Feedback zu deinen Zielen, zu deinem Verständnis und Workflow zu bekommen und den anderen Feedback zu geben. Damit ihr euch dabei besser versteht, nehmt euch kurz Zeit, über eure Vorstellung von konstruktivem Feedback zu sprechen.


### Reflexionsteil
- Wie können wir uns gegenseitig am besten Feedback geben, um unsere Ziele und Verständnis zu verbessern?


### Lernziel
- Du gewinnst Klarheit im Circle über das Vorgehen und die Organisation
