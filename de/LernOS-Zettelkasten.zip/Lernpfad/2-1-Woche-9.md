![Denken im Zettelkasten](images/Woche10.png)

## Woche 9 - Denken im Zettelkasten

Notizen sammeln ist schön und gut. Geht es dir nicht auch so, dass du Gedanken und Fragen dazu hast?

### Als Vorbereitung

- [ ] [Kata 14](2-1-Kata-14.md): Denken im Zettelkasten

### Im Weekly

- [ ] Check in (2 Minuten pro Member)

Was hat dich die letzte Woche im Zusammenhang mit persönlichem Wissensmanagement beschäftigt?

#### Leitfragen

- Wie hast du den Dialog mit deinem Zettelkasten für dich empfunden?
- Was sind die Vorteile des Denkens im Zettelkasten?
- Wie kann man objektive Vergleiche zwischen parallelen und widersprüchlichen Gedanken im Zettelkasten ziehen?
- Wie kann man den Zettelkasten als Gesprächspartner nutzen?
- Welche Art von Fragen kann man dem Zettelkasten stellen?
- Wie kann ich die Logik und Begründung in meinen Schlussfolgerungen überprüfen?

### Schluss

- [ ] Check-Out (1 Minute pro Member)

Was nimmst du dir für die nächste Woche vor?


