![Wenn du die Geschichte deines Lebens schreibst, lass niemand anderen den Stift in die Hand nehmen](images/woche1-2.png)

## Woche 0 - Den Sprint planen und Absprachen treffen

Bevor es losgeht, investiert etwas Zeit um euch kennenzulernen und die Rahmenbedingungen für euren Sprint abzusprechen.

### Im Weekly

- [ ] Check in (2 Minuten pro Member)

#### Leitfragen

- Worum geht es dir bei deinem persönlichem Wissensmanagement?
- Fängst du gerade an oder hast du bereits ein persönliches Wissensmanagement


- [ ] [Kata 0](2-1-Kata-0.md): Circle Setup (20 Minuten)

- [ ] [Kata 4](2-1-Kata-4.md): Feedback (10 Minuten)

### Schluss

- [ ] Check Out (1 Minute pro Member)

Was nimmst du dir für die nächste Woche vor?

<script src="https://giscus.app/client.js"
        data-repo="cogneon/lernos-zettelkasten"
        data-repo-id="R_kgDOI5YY1w"
        data-category="Announcements"
        data-category-id="DIC_kwDOI5YY184CUTx3"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="light"
        data-lang="de"
        crossorigin="anonymous"
        async>
</script>
