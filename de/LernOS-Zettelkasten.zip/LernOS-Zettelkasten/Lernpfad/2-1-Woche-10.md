![Denken im Zettelkasten](images/woche11.png)

## Woche 10 - Vertiefung zum Workflow

Diese Woche geht es darum zu reflektieren von wo du gekommen bist und welchen Workflow du nach den letzen Wochen umsetzt.

### Als Vorbereitung

- [ ] [Kata 17](2-1-Kata-17.md): Workflow vertiefen

### Im Weekly

- [ ] Check in (2 Minuten pro Member)

Was hat dich die letzte Woche im Zusammenhang mit persönlichem Wissensmanagement beschäftigt?

#### Leitfragen

- Hast du beim Erstellen deines Workflows neue Erkenntnisse gewonnen?

### Schluss

- [ ] Check-Out (1 Minute pro Member)

Was nimmst du dir für die nächste Woche vor?
