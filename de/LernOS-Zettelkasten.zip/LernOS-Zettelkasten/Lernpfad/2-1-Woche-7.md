![Stopp](images/Boxenstopp.png)

## Woche 7 - Boxenstopp

Hey, Herzlichen Glückwunsch! Du bist bis hierhin gekommen, das ist bereits ein Grund zum Feiern und sich gegenseitig auf die Schulter zu klopfen!

### Als Vorbereitung

- [ ] [Kata 10](2-1-Kata-10.md): bist du on Track?

- [ ] [Kata 11](2-1-Kata-11.md): Ausblick

### Im Weekly

- [ ] Check in (2 Minuten pro Member)

Was hat dich die letzte Woche im Zusammenhang mit persönlichem Wissensmanagement beschäftigt?

#### Leitfragen

- Fühlst du dich sicher im Umgang mit deinem Zettelkasten?
- Fühlst du dich wohl mit deinem Ziel und der bisherigen Erreichung?
- Habt ihr Fragen die ihr gerne untereinander besprechen wollt?

### Schluss

- [ ] Check-Out (1 Minute pro Member)

Was nimmst du dir für die nächste Woche vor?

<script src="https://giscus.app/client.js"
        data-repo="cogneon/lernos-zettelkasten"
        data-repo-id="R_kgDOI5YY1w"
        data-category="Announcements"
        data-category-id="DIC_kwDOI5YY184CUTx3"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="light"
        data-lang="de"
        crossorigin="anonymous"
        async>
</script>
