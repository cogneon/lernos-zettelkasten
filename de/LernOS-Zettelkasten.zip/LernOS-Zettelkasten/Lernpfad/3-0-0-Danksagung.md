![Danksagung](images/Danksagung.png)
# Danksagung

Geschrieben wurde der Leitfaden von: [Andreas Trebing](https://www.linkedin.com/in/andreas-trebing-32872b143/), [Friederike Schoeller-Frey](https://www.linkedin.com/in/frey-32753b67/), [Maris Krobath](https://www.linkedin.com/in/martina-krobath/)


Ein großes Dankeschön für konstruktives Feedback und Korrekturen geht an:

- Moritz Meißner
- Stephan Diepolder
